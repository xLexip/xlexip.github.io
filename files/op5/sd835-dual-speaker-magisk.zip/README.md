Changelog:

v1 - Initial Release
V2 - Fix for new Magisk Template