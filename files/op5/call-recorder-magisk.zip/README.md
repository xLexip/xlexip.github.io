##### Google Dialer | Magisk Module

##### NOTES: You Can't Update Google Dialer From PlayStore After Installing This Module. And Don't Update.

```
- A Magisk Module For Enabling Call Recording Option In Google Dialer.
```

- Support Channel - [Akira Release](https://t.me/AkiraRelease)
- Support Group - [Akira Discussion](https://t.me/AkiraDiscussion)

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.

##### Yes, works on all ROMs and on all firmwares.

##### ✓ INSTALLATION: Just flash via Magisk and reboot.
